//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//数组的创建
var array : [Int] = [Int]()
print("\(array)")

array.append(2)
array.append(3)
array.append(10)

var thressSix = Array(repeating: 6, count: 3)
print(thressSix)

var threeEight = Array(repeating: 8, count: 3)
print(threeEight)

var newArr = thressSix + threeEight
print(newArr)


//字面量
var shoppingList = ["milk","Eggs","Alice"]
print(shoppingList)

if shoppingList.isEmpty {
    print("shoppingList is Empty")
}else{
    print("shoppingList is not Empty")
}
shoppingList.append("Four")
print(shoppingList)

shoppingList += ["Five" , "Six"]
print(shoppingList)

shoppingList[1] = "rice"
print(shoppingList)

shoppingList.insert(" ", at: 0)
print(shoppingList)
shoppingList.removeLast()
print(shoppingList)

//遍历数组
for item in shoppingList {
    print(item)
}
for (index,value) in shoppingList.enumerated() {
    print("index \(index + 1) is \(value)")
}

//Set集合
let letters = Set<Character>()
print("letters is type of Set<Character> with \(letters.count) items")

//var favoriteGeres : Set<String> = ["Rock","Classical","Hip hop"]
var favoriteGeres : Set = ["Rock","Classical","Hip pop"]
print(favoriteGeres)
print("\(favoriteGeres.count)")

if let removeRock = favoriteGeres.remove("Rock") {
    print("\(removeRock)? I'm over it")
}
if favoriteGeres.contains("Rock") {
    print("I get up on the good foot")
}else{
    print("it's too funky in here")
}
//for item in favoriteGeres {
//    print("\(item)")
//}
//for genre in favoriteGeres.sorted(){
//    print("\(genre)")
//}
